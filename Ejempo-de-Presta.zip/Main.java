import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Crear el ArrayList de componentes
        ArrayList<String> listaDeComponentes = new ArrayList<>();
        // Agregar componentes a la lista (como se hizo anteriormente)
      listaDeComponentes.add("Resistencia de 10 ohmios");
      listaDeComponentes.add("Resistencia de 22 ohmios");
      listaDeComponentes.add("Resistencia de 47 ohmios");
      listaDeComponentes.add("Resistencia de 100 ohmios");
      listaDeComponentes.add("Resistencia de 220 ohmios");
      listaDeComponentes.add("Resistencia de 470 ohmios");
      listaDeComponentes.add("Resistencia de 1 kiloohmio");
      listaDeComponentes.add("Resistencia de 2.2 kiloohmios");
      listaDeComponentes.add("Resistencia de 4.7 kiloohmios");
      listaDeComponentes.add("Capacitor de 10 microfaradios");
      listaDeComponentes.add("Capacitor de 22 microfaradios");
      listaDeComponentes.add("Capacitor de 47 microfaradios");
      listaDeComponentes.add("Capacitor de 100 microfaradios");
      listaDeComponentes.add("LED rojo");
      listaDeComponentes.add("LED verde");
      
      // Crear un Scanner para la entrada del usuario
      Scanner scanner = new Scanner(System.in);
      
      
      // Solicitar la matrícula del alumno
      System.out.print("Ingrese su matrícula de alumno: ");
      String matricula = scanner.nextLine();
      
      // Mostrar la lista de componentes disponibles
      System.out.println("Lista de Componentes Disponibles:");
      
      for (int i = 0; i < listaDeComponentes.size(); i++) {
        System.out.println((i + 1) + ". " + listaDeComponentes.get(i));
      }

      // Crear un ArrayList para almacenar los componentes seleccionados
        ArrayList<String> pedido = new ArrayList<>();

        // Permitir al alumno seleccionar componentes
        while (true) {
            System.out.print("Ingrese el número del componente que desea (0 para finalizar): ");
            int opcion = scanner.nextInt();

            if (opcion == 0) {
                break; // El alumno ha finalizado la selección
            } else if (opcion >= 1 && opcion <= listaDeComponentes.size()) {
                String componenteElegido = listaDeComponentes.get(opcion - 1);
                pedido.add(componenteElegido);
                System.out.println("Componente agregado al pedido: " + componenteElegido);
            } else {
                System.out.println("Opción inválida, intente de nuevo.");
            }
        }

        // Mostrar el pedido del alumno
        System.out.println("Pedido del alumno: " + matricula);
        for (String componente : pedido) {
            System.out.println(componente);
        }

        // El encargado puede aceptar o rechazar el pedido
        System.out.print("¿El encargado acepta el pedido? (Si/No): ");
        String respuestaEncargado = scanner.next();

        if (respuestaEncargado.equalsIgnoreCase("Si")) {
            System.out.println("Pedido aceptado. Los componentes serán entregados.");
        } else {
            System.out.println("Pedido rechazado. Comuníquese con el encargado para más información.");
        }

        // Cerrar el Scanner
        scanner.close();
    }
}
